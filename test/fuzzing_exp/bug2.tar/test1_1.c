#include "stdio.h"
int main() {
printf("%d\n",  20 * -46 <  -43 / -99 / -46 * (  52 % (  -63 % -36 / -41 / 14 % -52 )  ) );
}
